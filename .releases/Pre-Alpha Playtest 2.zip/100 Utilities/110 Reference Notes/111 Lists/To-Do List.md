# Equipment 
## Armor 
## Weapons 
## General
---
# Examples 
- [ ] Example Species 
- [ ] Example Job 
- [ ] Example School 
- [ ] Example Weapon
---
# Feedback Improvements 
---
# Tags 
---
# Templates 

---
# Traits 

---
# Updates 
---
# Rules Text 
- [ ] Modes Of Play 
	- [ ] Downtime
	- [ ] Exploration
	- [ ] Camping
	- [ ] Engagement